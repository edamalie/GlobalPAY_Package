=== WooCommerce GlobalPAY Gateway ===

A payment gateway for GlobalPAY. A GlobalPAY merchant account, merchant key and merchant ID are required for this gateway to function.

== Important Note ==

An SSL certificate is recommended for additional safety and security for your customers.

Your callback url is https://your-site-url.com/wc-api/wc_gateway_globalpay